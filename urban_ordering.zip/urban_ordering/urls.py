"""
URL configuration for urban_ordering project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings             # <-- Add this
from django.conf.urls.static import static   # <-- Add this

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('dashboards.urls')),         # Keeps dashboard/home at the root "127.0.0.1:8000/"
    path('accounts/', include('accounts.urls')),  # Moves accounts to "127.0.0.1:8000/accounts/..."
    path('menu/', include('products.urls')),      # Moves products to "127.0.0.1:8000/menu/..."
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)